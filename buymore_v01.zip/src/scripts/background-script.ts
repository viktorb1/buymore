import { fetchMercariData } from "./sources/mercari";
import { fetchGoodwillData } from "./sources/goodwill"
import { fetchOfferupData } from "./sources/offerup";
import { fetchCraigslistData} from "./sources/craigslist"
import type { ReturnedData } from "./types"
import { fetchEbayData } from "./sources/ebay";
import { getChromeStorage, setChromeStorage } from "./chromeStorage";
import { removeSeenItems } from "./trimmer";

chrome.runtime.onMessage.addListener((request, _, sendResponse) => {

  if (request.action === "fetchData" && (request.query && request.query.length > 0)) {
      (async () => {
        const craigslistData: ReturnedData[] = await fetchCraigslistData(request.query);
        const mercariData: ReturnedData[] = await fetchMercariData(request.query);
        const goodwillData: ReturnedData[] = await fetchGoodwillData(request.query);
        const offerupData: ReturnedData[] = await fetchOfferupData(request.query);
        const ebayData: ReturnedData[] = await fetchEbayData(request.query);

        sendResponse({
          "craigslist": craigslistData,
          "mercari": mercariData,
          "goodwill": goodwillData,
          "offerup": offerupData,
          "ebay": ebayData
        })
      })();

      return true;
    }

    sendResponse({})
    return true;
  })

chrome.runtime.onInstalled.addListener(async () => {
  await fetchDataAndUpdateBadge()
  chrome.alarms.create('fetchDataEveryHour', { periodInMinutes: 60 });
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'fetchDataEveryHour') {
    fetchDataAndUpdateBadge();
  }
});

async function fetchDataAndUpdateBadge() {
  // console.log("here you go:::")
  // console.log(await getChromeStorage('item_counts'))
  const queries = (await getChromeStorage('queries') || []) as {query: string}[]
  let total_count = 0


  const item_counts = {} as Record<string, number>


  const counts = queries.map(async (request) => {

    const craigslistData: ReturnedData[] = await fetchCraigslistData(request.query);
    const mercariData: ReturnedData[] = await fetchMercariData(request.query);
    const goodwillData: ReturnedData[] = await fetchGoodwillData(request.query);
    const offerupData: ReturnedData[] = await fetchOfferupData(request.query);
    const ebayData: ReturnedData[] = await fetchEbayData(request.query);

    const data = {
      "craigslist": craigslistData,
      "mercari": mercariData,
      "goodwill": goodwillData,
      "offerup": offerupData,
      "ebay": ebayData
    }

    const trimmedData: ReturnedData[] = await removeSeenItems(data, request)
    try {
      item_counts[request.query] = trimmedData.length
    } catch (e) {
      console.log("it failed", e)
      console.log(trimmedData)
    }

    return trimmedData.length
  })

  for (const num of counts) {
    total_count += (await num)
  }

  await setChromeStorage("item_counts", item_counts)
  // console.log(counts)
  total_count = Math.min(total_count, 999)

  // console.log("updating value to", Math.min(total_count, 999))
  chrome.action.setBadgeText({ text: total_count.toString() == '0' ? '': total_count.toString() });
  chrome.action.setBadgeBackgroundColor({ color: '#962821' });

}

chrome.action.onClicked.addListener(() => {
  console.log("running")
  chrome.tabs.create({ url: "src/web/settings.html" });
});
import { useEffect } from "react";

function App() {
  useEffect(() => {}, []);

  return <></>;
}

export default App;
